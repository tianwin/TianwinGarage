from pathlib import Path

import streamlit as st


APP_DIR = Path(__file__).parent
HERO_IMAGE = APP_DIR / "assets" / "tianwins-garage-hero.png"

BUSINESS_NAME = "Tianwin's Garage"
SERVICE_AREA = "Rowland Heights, San Gabriel Valley, Orange County, and nearby areas"
CONTACT_EMAIL = "tianwin.garage@gmail.com"
CONTACT_LINE = f"Email {CONTACT_EMAIL}"


st.set_page_config(
    page_title=f"{BUSINESS_NAME} | Mobile Auto Repair",
    page_icon="TG",
    layout="wide",
)


def css() -> str:
    hero_url = HERO_IMAGE.as_posix()
    return f"""
    <style>
    :root {{
        --ink: #172026;
        --muted: #5e6872;
        --paper: #f7f5f1;
        --panel: #ffffff;
        --line: #ddd7cd;
        --accent: #c4472d;
        --accent-dark: #8f2f20;
        --green: #2f6f55;
    }}

    .stApp {{
        background: var(--paper);
        color: var(--ink);
    }}

    .block-container {{
        padding-top: 0;
        padding-left: 0;
        padding-right: 0;
        max-width: none;
    }}

    header, [data-testid="stToolbar"], [data-testid="stDecoration"] {{
        display: none;
    }}

    .site-nav {{
        position: sticky;
        top: 0;
        z-index: 50;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 20px;
        padding: 16px min(6vw, 72px);
        background: rgba(247, 245, 241, 0.94);
        border-bottom: 1px solid var(--line);
        backdrop-filter: blur(14px);
    }}

    .brand {{
        font-size: 20px;
        font-weight: 800;
        letter-spacing: 0;
        color: var(--ink);
    }}

    .nav-links {{
        display: flex;
        gap: 22px;
        color: var(--muted);
        font-size: 14px;
        font-weight: 600;
    }}

    .nav-links a {{
        color: inherit;
        text-decoration: none;
    }}

    .hero {{
        min-height: 78vh;
        display: flex;
        align-items: center;
        padding: 72px min(6vw, 72px);
        background:
            linear-gradient(90deg, rgba(23,32,38,0.94) 0%, rgba(23,32,38,0.72) 42%, rgba(23,32,38,0.10) 78%),
            url("{hero_url}") center right / cover no-repeat;
        color: white;
    }}

    .hero-content {{
        max-width: 680px;
    }}

    .eyebrow {{
        color: #f0c3ac;
        font-size: 14px;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        margin-bottom: 14px;
    }}

    h1 {{
        font-size: clamp(44px, 7vw, 86px);
        line-height: 0.96;
        margin: 0 0 22px;
        font-weight: 900;
        letter-spacing: 0;
    }}

    .hero p {{
        font-size: 20px;
        line-height: 1.55;
        max-width: 610px;
        color: rgba(255,255,255,0.88);
        margin: 0 0 30px;
    }}

    .hero-actions {{
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
        align-items: center;
    }}

    .primary-button, .secondary-button {{
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-height: 46px;
        padding: 0 20px;
        border-radius: 6px;
        text-decoration: none;
        font-weight: 800;
    }}

    .primary-button {{
        background: var(--accent);
        color: white;
    }}

    .secondary-button {{
        color: white;
        border: 1px solid rgba(255,255,255,0.45);
    }}

    .section {{
        padding: 64px min(6vw, 72px);
    }}

    .section.alt {{
        background: #ede8df;
    }}

    .section-title {{
        max-width: 820px;
        margin-bottom: 32px;
    }}

    .section-title h2 {{
        font-size: clamp(30px, 4vw, 48px);
        line-height: 1.05;
        margin: 0 0 12px;
        letter-spacing: 0;
    }}

    .section-title p {{
        color: var(--muted);
        font-size: 18px;
        line-height: 1.55;
        margin: 0;
    }}

    .grid {{
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 16px;
    }}

    .service {{
        background: var(--panel);
        border: 1px solid var(--line);
        border-radius: 8px;
        padding: 22px;
        min-height: 178px;
    }}

    .service h3 {{
        margin: 0 0 10px;
        font-size: 21px;
        letter-spacing: 0;
    }}

    .service p {{
        margin: 0;
        color: var(--muted);
        line-height: 1.55;
    }}

    .proof-band {{
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 1px;
        background: var(--line);
        border-top: 1px solid var(--line);
        border-bottom: 1px solid var(--line);
    }}

    .proof {{
        background: #ffffff;
        padding: 28px min(4vw, 44px);
    }}

    .proof strong {{
        display: block;
        font-size: 30px;
        color: var(--accent-dark);
        margin-bottom: 6px;
    }}

    .proof span {{
        color: var(--muted);
        font-weight: 700;
    }}

    .process {{
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 14px;
    }}

    .step {{
        border-top: 3px solid var(--accent);
        padding-top: 16px;
    }}

    .step strong {{
        display: block;
        margin-bottom: 8px;
        font-size: 18px;
    }}

    .step p {{
        margin: 0;
        color: var(--muted);
        line-height: 1.5;
    }}

    .quote {{
        background: var(--ink);
        color: white;
        padding: 56px min(6vw, 72px);
    }}

    .quote-inner {{
        max-width: 980px;
    }}

    .quote p {{
        font-size: clamp(26px, 4vw, 44px);
        line-height: 1.18;
        margin: 0 0 18px;
        font-weight: 850;
    }}

    .quote span {{
        color: rgba(255,255,255,0.72);
        font-size: 17px;
    }}

    .contact-layout {{
        display: grid;
        grid-template-columns: 1.15fr 0.85fr;
        gap: 28px;
        align-items: start;
    }}

    .contact-box {{
        background: var(--panel);
        border: 1px solid var(--line);
        border-radius: 8px;
        padding: 28px;
    }}

    .contact-box h3 {{
        margin: 0 0 14px;
        font-size: 26px;
    }}

    .contact-list {{
        display: grid;
        gap: 12px;
        margin-top: 18px;
    }}

    .contact-item {{
        padding: 14px 0;
        border-top: 1px solid var(--line);
    }}

    .contact-item strong {{
        display: block;
        margin-bottom: 4px;
    }}

    .contact-item span {{
        color: var(--muted);
    }}

    .footer {{
        padding: 26px min(6vw, 72px);
        background: #11181d;
        color: rgba(255,255,255,0.68);
        font-size: 14px;
    }}

    @media (max-width: 900px) {{
        .site-nav {{
            align-items: flex-start;
            flex-direction: column;
            padding: 14px 20px;
        }}
        .nav-links {{
            flex-wrap: wrap;
            gap: 12px;
            font-size: 13px;
        }}
        .hero {{
            min-height: 72vh;
            padding: 56px 20px;
            background:
                linear-gradient(90deg, rgba(23,32,38,0.94) 0%, rgba(23,32,38,0.74) 100%),
                url("{hero_url}") center / cover no-repeat;
        }}
        .hero p {{
            font-size: 17px;
        }}
        .section, .quote, .footer {{
            padding-left: 20px;
            padding-right: 20px;
        }}
        .grid, .process, .proof-band, .contact-layout {{
            grid-template-columns: 1fr;
        }}
    }}
    </style>
    """


st.markdown(css(), unsafe_allow_html=True)

st.markdown(
    f"""
    <nav class="site-nav">
        <div class="brand">{BUSINESS_NAME}</div>
        <div class="nav-links">
            <a href="#services">Services</a>
            <a href="#process">Process</a>
            <a href="#work">Recent Work</a>
            <a href="#contact">Contact</a>
        </div>
    </nav>

    <section class="hero">
        <div class="hero-content">
            <div class="eyebrow">ASE Certified Automotive Technician</div>
            <h1>{BUSINESS_NAME}</h1>
            <p>Professional mobile auto repair and diagnostics for BMW, Benz, Lexus, Toyota, Honda, and daily drivers. From maintenance to major repairs, every job is handled with clear estimates, careful workmanship, and appointment-based service.</p>
            <div class="hero-actions">
                <a class="primary-button" href="#contact">Request an appointment</a>
                <a class="secondary-button" href="#services">View services</a>
            </div>
        </div>
    </section>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    """
    <section class="proof-band" id="work">
        <div class="proof"><strong>27</strong><span>documented repair orders</span></div>
        <div class="proof"><strong>19</strong><span>brake service jobs</span></div>
        <div class="proof"><strong>$6.3k+</strong><span>tracked customer work</span></div>
        <div class="proof"><strong>ASE</strong><span>certified automotive technician</span></div>
    </section>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    """
    <section class="section" id="services">
        <div class="section-title">
            <h2>Major repairs, diagnostics, and maintenance without the shop runaround.</h2>
            <p>Specialized service for BMW, Benz, Lexus, Toyota, and Honda, with parts, labor, and repair options discussed before work begins.</p>
        </div>
        <div class="grid">
            <div class="service"><h3>BMW & Benz</h3><p>European vehicle service, diagnostics, brakes, suspension, maintenance, and repair planning with careful parts fitment.</p></div>
            <div class="service"><h3>Lexus, Toyota & Honda</h3><p>Reliable service for daily drivers and family cars, from maintenance to larger repairs.</p></div>
            <div class="service"><h3>Major Repairs</h3><p>Suspension, ignition, control arms, brake systems, engine-related service, and larger repair jobs by appointment.</p></div>
            <div class="service"><h3>Brake Service</h3><p>Brake pads, rotors, brake fluid, sensors, and related inspections for Asian and European vehicles.</p></div>
            <div class="service"><h3>Diagnostics</h3><p>Check-engine-light support, symptom review, issue tracing, and repair planning before parts are ordered.</p></div>
            <div class="service"><h3>Maintenance</h3><p>Oil changes, filters, wipers, batteries, fluid service, and regular maintenance items.</p></div>
            <div class="service"><h3>Parts Support</h3><p>Help identifying parts, checking fitment, ordering, installing, and handling return notes when needed.</p></div>
            <div class="service"><h3>Mobile Repair Visits</h3><p>Appointment-based repair at your home or nearby location when the job is suitable for mobile service.</p></div>
            <div class="service"><h3>Roadside Help</h3><p>Local assistance for battery, inspection, and other issues when a mobile visit makes sense.</p></div>
        </div>
    </section>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    """
    <section class="quote">
        <div class="quote-inner">
            <p>“I am an ASE Certified Automotive Technician. I specialize in BMW, Benz, Lexus, Toyota, and Honda, and I take on both maintenance and major repair work with careful documentation.”</p>
            <span>Tianwin, ASE Certified Automotive Technician</span>
        </div>
    </section>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    f"""
    <section class="section alt" id="process">
        <div class="section-title">
            <h2>Simple appointment flow.</h2>
            <p>Send the car information, describe the issue, and get a clear repair plan before the appointment.</p>
        </div>
        <div class="process">
            <div class="step"><strong>1. Send details</strong><p>Year, make, model, VIN if available, mileage, photos, and the issue you want checked.</p></div>
            <div class="step"><strong>2. Diagnose and plan</strong><p>The issue, repair scope, parts, fitment, cost, and availability are reviewed before work begins.</p></div>
            <div class="step"><strong>3. Repair visit</strong><p>Mobile service at your home or nearby location, depending on job type, tools, safety, and schedule.</p></div>
            <div class="step"><strong>4. Follow-up</strong><p>Work notes, payment status, and warranty follow-up are kept organized.</p></div>
        </div>
    </section>

    <section class="section" id="contact">
        <div class="section-title">
            <h2>Book a repair visit.</h2>
            <p>{SERVICE_AREA}</p>
        </div>
        <div class="contact-layout">
            <div class="contact-box">
                <h3>What to send</h3>
                <div class="contact-list">
                    <div class="contact-item"><strong>Vehicle</strong><span>Year, make, model, mileage, VIN if available.</span></div>
                    <div class="contact-item"><strong>Problem</strong><span>Describe the symptom and include photos or dashboard warning lights.</span></div>
                    <div class="contact-item"><strong>Location</strong><span>City or cross streets so the appointment can be planned.</span></div>
                    <div class="contact-item"><strong>Timing</strong><span>Preferred day and time window.</span></div>
                </div>
            </div>
            <div class="contact-box">
                <h3>Contact</h3>
                <div class="contact-list">
                    <div class="contact-item"><strong><a href="mailto:{CONTACT_EMAIL}" style="color: var(--ink); text-decoration: none;">{CONTACT_EMAIL}</a></strong><span>Share photos and vehicle details for a faster estimate.</span></div>
                    <div class="contact-item"><strong>Service area</strong><span>{SERVICE_AREA}</span></div>
                    <div class="contact-item"><strong>Availability</strong><span>By appointment only.</span></div>
                </div>
                <p style="margin-top: 22px; color: var(--muted); line-height: 1.55;">For urgent safety issues, avoid driving the vehicle until it has been checked.</p>
            </div>
        </div>
    </section>

    <footer class="footer">
        {BUSINESS_NAME} · ASE Certified Automotive Technician · Mobile auto repair · By appointment only
    </footer>
    """,
    unsafe_allow_html=True,
)
